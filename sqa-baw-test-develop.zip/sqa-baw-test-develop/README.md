# Bulk Action Tool BDD Automation

Welcome to the Bulk Action Tool BDD Automation Framework

## Getting Started

1. Install Java Amazon Corretto JDK 11 [Installation Guide](https://docs.aws.amazon.com/corretto/latest/corretto-11-ug/windows-7-install.html)
   
2. Install Gradle 6.7 [Installation Guide](https://gradle.org/install/)

3. Review the appropriate 'qa.properties', 'dev.properties', 'ppe.properties' file to ensure all credential and path
   configurations are correct for your local environment.
   [e.g. 'jc-api/src/main/resources/config/qa.properties']

4. Enable the Cucumber plugin within IntelliJ (May already be installed/enabled by default)
   * From IntelliJ, click 'File' and select 'Settings'.
   * Select 'Plugins'.
   * Select 'Cucumber for Java' and click 'Install'.
   * Click 'OK'.

5. Tests can be run in three ways:
   5.1 Set test run as a build configuration
         * On the top toolbar of IntelliJ, select 'Run --> Edit Configurations'.
         * Click on the '+' at the top left and choose 'Gradle'.
         * Name the run configuration as: 'bulk-action-tool-bdd'.
         * Enter into the 'Tasks:' --> clean cucumber.
         * VM options (example): -Denv=dev -Dtags="@ui and not @ignored" -Dtests="ui"
         * Refer to Jenkins for recent examples of variable usage.

   5.2 From command line:
      * Go to required module/folder from command line.
      * Use command providing the full path to the main project folder:
        .\bulk-action-tool-bdd\gradlew clean cucumber -Denv=dev

   5.3 From feature file:
      * If a non-QA environment is required, go to PropertyLoader [e.g. 'bat-utils/src/main/java/com/refinitiv/bat/utils']
        and replace "String env = System.getProperty("env", "qa");" by "String env = System.getProperty("env", "dev");"
      * Click on Run button >> on the left of the feature/scenario name.
      * Choose "Run feature/scenario".
