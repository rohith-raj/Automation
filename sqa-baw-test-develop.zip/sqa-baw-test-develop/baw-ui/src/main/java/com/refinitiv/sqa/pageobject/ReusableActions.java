package com.refinitiv.sqa.pageobject;

import com.refinitiv.sqa.webdriver.allDriver;

import java.util.Properties;

import static com.codeborne.selenide.Selenide.$;
import static com.refinitiv.sqa.utils.PropertyLoader.readProperty;
import com.refinitiv.sqa.pageobject.MicrosoftLoginPage;

public class ReusableActions extends MicrosoftLoginPage{

    public void loginToBAW() throws InterruptedException {

        Properties prop = readProperty("src/main/resources/config/local.properties");
        String email = prop.getProperty("email");
        String password = prop.getProperty("password");
        String azureKey = prop.getProperty("azureKey");
        //String url = prop.getProperty("bawUrl");
        signIn(email,password,azureKey);

    }

}
