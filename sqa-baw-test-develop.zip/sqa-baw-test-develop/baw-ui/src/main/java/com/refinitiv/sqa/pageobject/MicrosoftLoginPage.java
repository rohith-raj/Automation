package com.refinitiv.sqa.pageobject;

import com.codeborne.selenide.Condition;
import com.refinitiv.sqa.common.helper;
import com.refinitiv.sqa.webdriver.allDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.jboss.aerogear.security.otp.Totp;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;


public class MicrosoftLoginPage extends helper {

    private long waitDuration = 30;
    public void signIn(final String email, final String password, final String azureKey) throws InterruptedException {

        //enterEmail(email);
       // clickNext();
        //enterPassword(password);
       // clickSignIn();
        enterGeneratedOTP(azureKey);
        clickVerifyButton();
        //clickNotNow();
        //clickYesToStaySignedIn();
    }


    private void clickNotNow() throws InterruptedException {
        Thread.sleep(1000);
        $(".form-group a").click();

    }

    private void clickYesToStaySignedIn() {
        $("input[value='Yes']").click();
    }

    private void clickVerifyButton() {

        driverWaitByXpath("//div/input[@value='Verify']");
        driver.findElement(By.xpath("//div/input[@value='Verify']")).click();

    }

    private void clickSignIn() {
        $("input[value='Sign in']").click();
    }

    private void enterPassword(final String password) {
        $("input[type='password']").shouldBe(Condition.visible, Duration.ofSeconds(30)).sendKeys(password);
    }

    private void clickNext() {
        $("input[value='Next']").click();
    }

    private void enterEmail(final String email) {

        WebElement emailUi = driver.findElement(By.cssSelector("input[type='email']"));

        if(emailUi.isDisplayed()){
            emailUi.sendKeys(email);
        }

    }

    public void enterGeneratedOTP(final String azureKey) {
        Totp generatedOTP = new Totp(azureKey);
        waitDriver = new WebDriverWait(driver, Duration.ofSeconds(waitDuration));
        waitDriver.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("input[aria-label='Code']")));
        driver.findElement(By.cssSelector("input[aria-label='Code']")).sendKeys(generatedOTP.now());
    }

}

