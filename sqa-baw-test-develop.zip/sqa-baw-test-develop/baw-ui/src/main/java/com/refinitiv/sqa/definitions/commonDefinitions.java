package com.refinitiv.sqa.definitions;

import com.refinitiv.sqa.pageobject.ReusableActions;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import com.refinitiv.sqa.webdriver.allDriver;
import com.refinitiv.sqa.common.helper;
import lombok.AllArgsConstructor;
import static com.refinitiv.sqa.common.helper.executePowerShell;


@AllArgsConstructor
public class commonDefinitions extends allDriver  {

    private final helper helper;
    private final ReusableActions ReusableActions;


    @Before
    public void setup() {

        allDriver allDriver_instance = allDriver.getInstance();
        driver = allDriver_instance.setupChromeDriver();

    }

    @Given("User login with into BAW UI")
    public void authenticatorLogin() throws InterruptedException {

        ReusableActions.loginToBAW();
        System.out.println("Login Successful");

    }

    @When("User click on Single QA Inbox")
    public void open_task_list() {

        String xpath = "//a[contains(text(),'Show more')]";
        driverWaitByXpath(xpath);
        helper.jsClick(xpath);

         xpath = "//div[@class = 'menu-link-table']//a[@title='Single QA Inbox New']";
        driverWaitByXpath(xpath);
        helper.jsClick(xpath);

    }

    @And("Claim Task")
    public void claim_task() throws InterruptedException{

        String xpath = "(//div/span[contains(text(),'Review Record')])[1]";
        driverWaitByXpath(xpath);
        helper.jsClick(xpath);
        Thread.sleep(8000);
    }
    @After
    public void endSession(){
        //executePowerShell();
        driver.close();
    }
}
