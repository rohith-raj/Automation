package com.refinitiv.sqa.definitions;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import com.refinitiv.sqa.utils.webdriver.allDriver;
import com.refinitiv.sqa.common.helper;
import lombok.AllArgsConstructor;


@AllArgsConstructor
public class commonDefinitions extends allDriver  {

    private final helper helper;


    @Before
    public void setup() {
        setupChromeDriver();
    }

    @Given("User login with into BAW UI")
    public void authentocatorLogin(){

        System.out.println("Call Login Method");

    }


    @Given("User access the BAW Process Portal Work Page")
    public void user_access_the_baw_process_portal_work_page() {
        openUrl();
    }

    @When("User click on Single QA Inbox")
    public void open_task_list() {

        String xpath = "//a[contains(text(),'Show more')]";
        driverWaitByXpath(xpath);
        helper.jsClick(xpath);

        xpath = "//div[@class = 'menu-link-table']//a[@title='Single QA Inbox New']";
        driverWaitByXpath(xpath);
        helper.jsClick(xpath);

    }

    @And("Claim Task")
    public void claim_task() throws InterruptedException{
        //String xpath = "(//div/span[@title='Review Record'])[2]";
        String xpath = "(//div/span[contains(text(),'Review Record')])[1]";
        //String xpath = "(//div/div[@class=\"ui-grid-cell ng-scope ui-grid-coluiGrid-0025 custom\"])[1]";
        driverWaitByXpath(xpath);
        helper.jsClick(xpath);
        Thread.sleep(10000);
    }
}
