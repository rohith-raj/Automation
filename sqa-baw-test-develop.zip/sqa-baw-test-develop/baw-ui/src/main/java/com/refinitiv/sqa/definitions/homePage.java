package com.refinitiv.sqa.definitions;


import io.cucumber.java.After;
import io.cucumber.java.en.*;
import io.cucumber.java.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import com.refinitiv.sqa.common.helper;
import org.openqa.selenium.WebElement;


public class homePage extends helper{

    JavascriptExecutor jse = (JavascriptExecutor)driver;

   @Then("User Publish the Request And Click on Submit")
    public void publish() throws InterruptedException{

       scrollMouse("Down",0);
       Thread.sleep(3000);
       jse.executeScript("document.querySelector('iframe[class=\"cshsTaskWindow fill-vertical\"]').contentDocument.querySelector('iframe').contentDocument.querySelector('input[id=\"radiogroup-item-input-Radio_button_group1[0]\"]').click()");
       jse.executeScript("document.querySelector('iframe[class=\"cshsTaskWindow fill-vertical\"]').contentDocument.querySelector('iframe').contentDocument.querySelector('textarea[id=\"textarea-textarea-Text_area1\"]').value=\"This Test Case is Automated\"");
       //jse.executeScript("document.querySelector('iframe[class=\"cshsTaskWindow fill-vertical\"]').contentDocument.querySelector('iframe').contentDocument.querySelector('#button-button-Button3').click()");

   }
   @Then("User click on Type check box in Query Reasons")
    public void queryReasons(){

       scrollMouse("Custom",10);
       jse.executeScript("document.querySelector('iframe[class=\"cshsTaskWindow fill-vertical\"]').contentDocument.querySelector('iframe').contentDocument.getElementById('checkbox-input-QueryReasonsCV2:queryReasonsList1:currentItem1[0]:Horizontal_layout2:typeOfQueryReasonFlag1').click()");

   }
   @And("User Enter Remarks in the Respective field of Type Query Reason")
    public void queryReason(){
       jse.executeScript("document.querySelector('iframe[class=\"cshsTaskWindow fill-vertical\"]').contentDocument.querySelector('iframe').contentDocument.getElementById('text-input-QueryReasonsCV2:queryReasonsList1:currentItem1[0]:Horizontal_layout2:textOfQueryReason1').value=\"Change Type\"");

   }
   @Then("User Reject the Request And Click on Submit")
    public void reject(){
       scrollMouse("Custom",15);
       jse.executeScript("document.querySelector('iframe[class=\"cshsTaskWindow fill-vertical\"]').contentDocument.querySelector('iframe').contentDocument.querySelector('input[id=\"radiogroup-item-input-Radio_button_group1[1]\"]').click()");
       //jse.executeScript("document.querySelector('iframe[class=\"cshsTaskWindow fill-vertical\"]').contentDocument.querySelector('iframe').contentDocument.querySelector('#button-button-Button3').click()");
   }

}






