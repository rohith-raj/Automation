package com.refinitiv.sqa.webdriver;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.Properties;

import static com.refinitiv.sqa.utils.PropertyLoader.readProperty;


public class allDriver {

    public  WebDriverManager driverMgr;
    public  static WebDriver driver;
    public  WebDriverWait waitDriver;
    private long waitDuration = 30;
    Properties prop = readProperty("src/main/resources/config/local.properties");
    String baseURL = prop.getProperty("bawUrl");

    private static allDriver allDriver_instance = null;

    public allDriver(){

    }

    public static allDriver getInstance(){
        if(allDriver_instance == null)
            allDriver_instance = new allDriver();
        return allDriver_instance;
    }

    public WebDriver setupChromeDriver(){

        driverMgr.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        openUrl();
        return driver;
    }

    public void openUrl(){
        driver.get(baseURL);
        waitDriver = new WebDriverWait(driver, Duration.ofSeconds(waitDuration));
    }

    public void driverWaitByXpath(String path){
        waitDriver = new WebDriverWait(driver, Duration.ofSeconds(waitDuration));
        waitDriver.until(ExpectedConditions.presenceOfElementLocated(By.xpath(path)));

    }


}
