package com.refinitiv.sqa.pageobject.base;


import com.codeborne.selenide.Selenide;
import com.refinitiv.sqa.utils.PropertyLoader;
import com.refinitiv.sqa.webdriver.allDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class WebPage  {


        @FindBy(how = How.XPATH, using = "//a[contains(text(),'Show more')]")
        WebElement showmore;
        @FindBy(how = How.XPATH, using = "//div[@class = 'menu-link-table']//a[@title='Single QA Inbox New']")
        WebElement dashboard;
        @FindBy(how = How.XPATH, using = "//div/span[contains(text(),'Review Record')])[1]")
        WebElement taskItem;


}
