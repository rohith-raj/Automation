package com.refinitiv.sqa.utils.webdriver;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;


public class allDriver {

    
    public  WebDriverManager driverMgr;
    public  static WebDriver driver;
    public  WebDriverWait waitDriver;
    private long waitDuration = 30;

    //All Drivers Set up
    public void setupChromeDriver(){

        driverMgr.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    public void firefoxDriver(){

        driverMgr.firefoxdriver().setup();
        driver = new FirefoxDriver();
        driver.manage().window().maximize();

    }

    public void openUrl(){
        driver.get(baseURL);
        waitDriver = new WebDriverWait(driver, Duration.ofSeconds(waitDuration));
    }

    public void driverWaitByXpath(String path){
        waitDriver = new WebDriverWait(driver, Duration.ofSeconds(waitDuration));
        waitDriver.until(ExpectedConditions.presenceOfElementLocated(By.xpath(path)));

    }
    public  void  driverWaitByClass(String path){
        waitDriver = new WebDriverWait(driver, Duration.ofSeconds(waitDuration));
        waitDriver.until(ExpectedConditions.presenceOfElementLocated(By.className(path)));
    }

    public void closeBrowser(){

        driver.close();
    }

    public void quitDriver() {
        if (driver != null) {
            driver.quit();
        }
    }

}
