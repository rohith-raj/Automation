package com.refinitiv.sqa.utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import static java.lang.System.getProperties;

public class PropertyLoader {

    private static Properties prop = new Properties();
    private static InputStream fileStream = null;

    public static Properties readProperty(String uri) {
        try {

            InputStream input = new FileInputStream(uri);
            prop.load(input);
            return prop ;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


}
