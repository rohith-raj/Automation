package com.refinitiv.sqa.common;
import com.codeborne.selenide.Selenide;
import com.profesorfalken.jpowershell.PowerShell;
import com.profesorfalken.jpowershell.PowerShellResponse;
import com.refinitiv.sqa.webdriver.allDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;


public class helper extends allDriver {

public static void scrollMouse(String direction,int value){

    try {
        Robot rb = new Robot();
        rb.setAutoDelay(100);

        if(direction == "Down") {
            rb.mouseWheel(25);
        }else if(direction == "Up") {
            rb.mouseWheel(-25);
        }else if(direction == "Custom"){
            rb.mouseWheel(value);
        }
    }catch (Exception e){
        System.out.println("Exception Caught in Scroll"+ e);
    }

}
    public static void jsClick(String xpath){
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("arguments[0].click();",driver.findElement(By.xpath(xpath)));
    }

    public void waitPageLoad(){
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("return document.readyState").toString().equals("complete");
    }

    public static void executePowerShell(){

        try {

            PowerShell powerShell = PowerShell.openSession();

            Map<String, String> config = new HashMap<String, String>();
            config.put("maxWait", "2000");

            PowerShellResponse response = powerShell.configuration(config).executeCommand("cd C:\\Users\\UC504629\\Downloads\\AutomationProjects\\sqa-baw-test-develop\\baw-ui");
            response = powerShell.configuration(config).executeCommand("allure generate allure-results --clean -o allure-report");
            System.out.println("Command Output Text:" + response.getCommandOutput());

        }catch(Exception e){
            System.out.println("Exception Occurred in Commandline-->> "+e);
        }

    }


}

